

<?php $__env->startSection('title', 'All Projects'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Hero Section -->
    <section class="projects-hero" style="padding-top: 120px; padding-bottom: 60px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white;">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 mx-auto text-center">
                    <h1 class="display-4 fw-bold mb-3" style="animation: fadeInUp 0.6s ease;">My Projects</h1>
                    <p class="lead mb-4" style="animation: fadeInUp 0.6s ease 0.2s; animation-fill-mode: both;">Projects I've worked on during my time at various companies</p>
                    <div style="animation: fadeInUp 0.6s ease 0.4s; animation-fill-mode: both;">
                        <span class="badge me-2 mb-2" style="background: rgba(255,255,255,0.2); padding: 10px 20px; border-radius: 25px; font-size: 0.9rem; font-weight: 500;">
                            <i class="bi bi-building"></i> Professional Experience
                        </span>
                        <span class="badge me-2 mb-2" style="background: rgba(255,255,255,0.2); padding: 10px 20px; border-radius: 25px; font-size: 0.9rem; font-weight: 500;">
                            <i class="bi bi-code-slash"></i> Real-World Solutions
                        </span>
                        <span class="badge mb-2" style="background: rgba(255,255,255,0.2); padding: 10px 20px; border-radius: 25px; font-size: 0.9rem; font-weight: 500;">
                            <i class="bi bi-rocket-takeoff"></i> Industry Projects
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Projects Grid -->
    <section class="py-5" style="background-color: #f8f9fa;">
        <div class="container">
            <div class="row g-4">
                <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-lg-4 col-md-6">
                    <div class="project-card h-100" style="border: none; border-radius: 15px; overflow: hidden; transition: all 0.3s ease; background: white; box-shadow: 0 5px 15px rgba(0,0,0,0.08);">
                        <div class="position-relative d-flex align-items-center justify-content-center" style="height: 200px; background: linear-gradient(135deg, <?php echo e(['#667eea', '#764ba2', '#3a86ff', '#f093fb', '#4facfe'][($loop->index % 5)]); ?> 0%, <?php echo e(['#764ba2', '#667eea', '#667eea', '#f5576c', '#00f2fe'][($loop->index % 5)]); ?> 100%);">
                            <div class="text-center">
                                <?php if($project->technologies): ?>
                                    <?php
                                        $techs = json_decode($project->technologies);
                                        $displayTechs = array_slice($techs, 0, 3);
                                    ?>
                                    <div class="d-flex flex-wrap justify-content-center gap-3 px-4">
                                        <?php $__currentLoopData = $displayTechs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="text-white" style="font-size: 2.5rem; opacity: 0.9;">
                                            <?php if(stripos($tech, 'php') !== false): ?>
                                                <i class="devicon-php-plain"></i>
                                            <?php elseif(stripos($tech, 'laravel') !== false): ?>
                                                <i class="devicon-laravel-plain"></i>
                                            <?php elseif(stripos($tech, 'javascript') !== false || stripos($tech, 'js') !== false): ?>
                                                <i class="devicon-javascript-plain"></i>
                                            <?php elseif(stripos($tech, 'react') !== false): ?>
                                                <i class="devicon-react-original"></i>
                                            <?php elseif(stripos($tech, 'vue') !== false): ?>
                                                <i class="devicon-vuejs-plain"></i>
                                            <?php elseif(stripos($tech, 'angular') !== false): ?>
                                                <i class="devicon-angularjs-plain"></i>
                                            <?php elseif(stripos($tech, 'node') !== false): ?>
                                                <i class="devicon-nodejs-plain"></i>
                                            <?php elseif(stripos($tech, 'python') !== false): ?>
                                                <i class="devicon-python-plain"></i>
                                            <?php elseif(stripos($tech, 'mysql') !== false): ?>
                                                <i class="devicon-mysql-plain"></i>
                                            <?php elseif(stripos($tech, 'mongodb') !== false): ?>
                                                <i class="devicon-mongodb-plain"></i>
                                            <?php elseif(stripos($tech, 'postgresql') !== false): ?>
                                                <i class="devicon-postgresql-plain"></i>
                                            <?php elseif(stripos($tech, 'java') !== false): ?>
                                                <i class="devicon-java-plain"></i>
                                            <?php elseif(stripos($tech, 'flutter') !== false): ?>
                                                <i class="devicon-flutter-plain"></i>
                                            <?php elseif(stripos($tech, 'asp.net') !== false || stripos($tech, 'asp') !== false): ?>
                                                <i class="devicon-dotnetcore-plain"></i>
                                            <?php elseif(stripos($tech, 'c#') !== false): ?>
                                                <i class="devicon-csharp-plain"></i>
                                            <?php elseif(stripos($tech, 'rest') !== false || stripos($tech, 'api') !== false): ?>
                                                <i class="bi bi-cloud"></i>
                                            <?php else: ?>
                                                <i class="bi bi-code-slash"></i>
                                            <?php endif; ?>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="position-absolute top-0 end-0 m-3">
                                <span class="badge" style="background: rgba(255,255,255,0.95); color: #667eea; font-weight: 600; padding: 8px 12px; border-radius: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
                                    <?php echo e(\Carbon\Carbon::parse($project->project_date)->format('M Y')); ?>

                                </span>
                            </div>
                        </div>
                        <div class="card-body p-4">
                            <h5 class="card-title fw-bold mb-3" style="color: #2d3748;"><?php echo e($project->title); ?></h5>
                            <p class="card-text text-muted mb-3" style="font-size: 0.95rem; line-height: 1.6;">
                                <?php echo e(Str::limit($project->description, 100)); ?>

                            </p>
                            
                            <?php if($project->technologies): ?>
                            <div class="mb-4">
                                <?php $__currentLoopData = json_decode($project->technologies); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="badge me-1 mb-2" style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 6px 12px; border-radius: 20px; font-weight: 500; font-size: 0.75rem;">
                                    <?php echo e($tech); ?>

                                </span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <?php endif; ?>
                            
                            <a href="<?php echo e(route('project.show', $project->slug)); ?>" 
                               class="btn w-100" 
                               style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; border: none; padding: 12px; border-radius: 10px; font-weight: 600; transition: all 0.3s ease;"
                               onmouseover="this.style.transform='translateY(-2px)'; this.style.boxShadow='0 5px 15px rgba(102, 126, 234, 0.4)'"
                               onmouseout="this.style.transform='translateY(0)'; this.style.boxShadow='none'">
                                View Details →
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12">
                    <div class="text-center py-5">
                        <div class="mb-4">
                            <svg width="120" height="120" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M9 2L7.17 4H4C2.9 4 2 4.9 2 6V18C2 19.1 2.9 20 4 20H20C21.1 20 22 19.1 22 18V6C22 4.9 21.1 4 20 4H16.83L15 2H9ZM12 17C9.24 17 7 14.76 7 12C7 9.24 9.24 7 12 7C14.76 7 17 9.24 17 12C17 14.76 14.76 17 12 17Z" fill="#cbd5e0"/>
                            </svg>
                        </div>
                        <h4 class="fw-bold mb-2" style="color: #2d3748;">No Projects Yet</h4>
                        <p class="text-muted mb-0">New projects will be added soon. Stay tuned!</p>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            
            <!-- Pagination -->
            <?php if($projects->hasPages()): ?>
            <div class="row mt-5">
                <div class="col-12 d-flex justify-content-center">
                    <nav aria-label="Page navigation">
                        <?php echo e($projects->links('pagination::bootstrap-5')); ?>

                    </nav>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </section>

    <style>
        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        .project-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 15px 35px rgba(102, 126, 234, 0.2) !important;
        }
        
        /* Custom Pagination Styles */
        .pagination {
            gap: 8px;
        }
        
        .pagination .page-link {
            border-radius: 10px;
            border: 2px solid #e9ecef;
            color: #667eea;
            font-weight: 600;
            padding: 10px 16px;
            transition: all 0.3s ease;
            min-width: 45px;
            text-align: center;
        }
        
        .pagination .page-link:hover {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-color: transparent;
            transform: translateY(-2px);
        }
        
        .pagination .page-item.active .page-link {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border-color: transparent;
            color: white;
        }
        
        .pagination .page-item.disabled .page-link {
            background: #f8f9fa;
            border-color: #e9ecef;
            color: #cbd5e0;
        }
        
        /* Hide default arrow text and use custom */
        .pagination .page-link[rel="prev"]::before {
            content: "←";
            font-size: 1.2rem;
        }
        
        .pagination .page-link[rel="next"]::before {
            content: "→";
            font-size: 1.2rem;
        }
        
        .pagination .page-link[rel="prev"],
        .pagination .page-link[rel="next"] {
            font-size: 0;
        }
        
        .pagination .page-link[rel="prev"]::before,
        .pagination .page-link[rel="next"]::before {
            font-size: 1.2rem;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\portofolio\resources\views/portfolio/projects.blade.php ENDPATH**/ ?>