<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PortfolioController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

Route::get('/', [PortfolioController::class, 'index'])->name('home');
Route::get('/projects', [PortfolioController::class, 'allProjects'])->name('projects.all');
Route::get('/project/{slug}', [PortfolioController::class, 'showProject'])->name('project.show');

// Routes untuk personal projects
Route::get('/personal-projects', [PortfolioController::class, 'allPersonalProjects'])->name('personal.projects.all');
Route::get('/personal-project/{slug}', [PortfolioController::class, 'showPersonalProject'])->name('personal.project.show');